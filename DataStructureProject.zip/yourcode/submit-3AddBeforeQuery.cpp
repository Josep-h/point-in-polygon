#include "submit-3AddBeforeQuery.h"

void SetEnvironmentFromAddBeforeQuery() {

}

void AddPointFromAddBeforeQuery(int id, double x, double y) {

}

void AddPolygonFromAddBeforeQuery(int id, int n, std::vector<std::pair<double, double> > &polygon) {

}

std::vector<int> QueryPointFromAddBeforeQuery(double x, double y) {
    return std::vector<int>();
}

std::vector<int> QueryPolygonFromAddBeforeQuery(int n, std::vector<std::pair<double, double> > &polygon) {
    return std::vector<int>();
}
