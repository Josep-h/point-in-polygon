#include "submit-4MixQueryPoint.h"

void SetEnvironmentFromMixQueryPoint() {

}

std::vector<int> QueryPointFromMixQueryPoint(double x, double y) {
    return std::vector<int>();
}

void AddPolygonFromMixQueryPoint(int id, int n, std::vector<std::pair<double, double> > &polygon) {

}

void DeletePolygonFromMixQueryPoint(int id) {

}
